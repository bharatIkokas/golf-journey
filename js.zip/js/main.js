// Travel Date Date Picker
$('input[name="travelDate"]').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
});

$('input[name="travelDate"]').val('');
$('input[name="travelDate"]').attr("placeholder", "Travel Date");


// Top Banner
$('.main-banner.owl-carousel').owlCarousel({
    loop:true,
    autoplay:true,
    autoplayTimeout:5000,
    autoplayHoverPause:true,
    smartSpeed: 1500,
    margin:0,
    responsiveClass:true,
    dots: true,
    nav: false,
    responsive:{
        0:{
            items:1
        },
        600:{
            items:1
        },
        1000:{
            items:1
        }
    }
});

// Menu Scorll
$(window).scroll(function() {
    var windscroll = $(window).scrollTop();
    if (windscroll >= 200) {
        $('section').each(function(i) {
    // The number at the end of the next line is how pany pixels you from the top you want it to activate.
            if ($(this).position().top <= windscroll - 0) {
                $('.menu-block li.active').removeClass('active');
                $('.menu-block li').eq(i).addClass('active');
            }
        });

    } else {

        $('.menu-block li.active').removeClass('active');
        $('.menu-block li:first').addClass('active');
    }

    }).scroll();


    // Video in Popup
    $('.testimonail-video').magnificPopup({
		type: 'iframe',
		mainClass: 'mfp-fade',
		removalDelay: 160,
		preloader: false,

		fixedContentPos: false
	});
